# GUI with python
from tkinter import*
root=Tk()

# Create a frame
my_label1=Label(root,text="fdthdfdtnhtv")
my_label2=Label(root,text="Hello world!")

# show it on screen
my_label1.grid(row=1,column=2)
my_label2.grid(row=0,column=0)

root.mainloop()

# GUI with python
from tkinter import*
root=Tk()

# Create a frame
my_label=Label(root,text="Hello world!")

# show it on screen
my_label.pack()
root.mainloop()
