# GUI with python
from tkinter import*
root=Tk()

myButton=Button(root,text ="click me!" , padx=50,pady=50)
myButton.pack()

root.mainloop()