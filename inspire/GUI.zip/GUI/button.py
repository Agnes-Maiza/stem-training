# GUI with python
from tkinter import*
root=Tk()

myButton=Button(root,text ="click me!" , state=DISABLED)
myButton.pack()

root.mainloop()